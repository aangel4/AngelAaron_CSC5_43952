/* 
 * File:   main.cpp
 * Author: Aaron Angel
 *
 * Created on March 9, 2015, 1:02 AM
 *      //Purpose: 8th Homework Problem
 */

#include <iostream>

using namespace std;

//User Libraries
//Global Constants
//Function Prototypes
//Personal Information

int main(int argc, char** argv) {
 
    
    //output Personal Information
    cout<<"Personal Information Problem\nAaron Angel\n5966 Dogwood St\nSan Bernardino CA 92404\n909-202-3479\nMajor in Computer Science\n";
 
  
    return 0;
}

