/* 
 * File:   main.cpp
 * Author: Aaron Angel
 *
 * Created on March 9, 2015, 1:02 AM
 *      //Purpose: 8th Homework Problem
 */

#include <iostream>

using namespace std;

//User Libraries
//Global Constants
//Function Prototypes
//Personal Information

int main(int argc, char** argv) {
 
    
    //output Personal Information
    cout<<"Personal Information Problem"<<endl;
    cout<<"Aaron Angel"<<endl;
    cout<<"5966 Dogwood St"<<endl;
    cout<<"San Bernardino CA 92404"<<endl;
    cout<<"909-202-3479"<<endl;
    cout<<"Major in Computer Science"<<endl;
    
    return 0;
}

